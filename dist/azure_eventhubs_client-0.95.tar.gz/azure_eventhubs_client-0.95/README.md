# azure_eventhubs_client
This is probably the fastest(and the easiest) Eventhubs Client as it uses Redis cache.
We encourage you see the examples and time the function runs.

We developed this locally for Azure Function Apps.
