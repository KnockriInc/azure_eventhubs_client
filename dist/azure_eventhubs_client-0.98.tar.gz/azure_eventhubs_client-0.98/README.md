# azure_eventhubs_client
Lightweight Azure EventHub client using redis.
